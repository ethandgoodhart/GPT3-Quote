from gpt3quote.Quote import Quote
