from gpt3_quote.Quote import Quote
